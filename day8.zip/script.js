function alertjs1(){
			alert('hii guys');
			document.getElementById('a').style.backgroundColor="blue";
		}
function promptjs2(){
			prompt('hii guys')
			document.getElementById('b').style.backgroundColor="red";
		}
function confirmjs3(){
			confirm('hii guys')
			document.getElementById('c').style.backgroundColor=prompt('enter color');
		}
function externalonchange(){

	document.body.style.backgroundColor=document.getElementById('cb1').value;
}

function ex(){
	document.getElementById('d').style.backgroundColor=document.getElementById('cb2').value;
}

function abc(){
var name = prompt('enter your name');
document.getElementById('b3').innerHTML=name;
} 	

console.log('hii');